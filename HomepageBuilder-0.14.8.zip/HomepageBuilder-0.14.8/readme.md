# HomePageBuilder(EN)
A Frame to building Homepages for PCL2. Using Markdown to generate complexe homepages.

Can run in server mode, respond homepage requests.

# 主页构建器(ZH)
一个PCL主页构建器框架，从基本的XAML或者其它比如Markdown类似的代码生成一个用于PCL的主页文件，以方便复杂主页的维护

构建器可在两种模式下运行：构建器模式和服务器模式。构建器使用工程文件生成主页代码；服务器使用工程文件响应来自PCL的请求，提供联网更新

使用文档见：https://builder.docs.bugjump.net/
文档仓库：https://github.com/Light-Beacon/HomepageBuilderDocument