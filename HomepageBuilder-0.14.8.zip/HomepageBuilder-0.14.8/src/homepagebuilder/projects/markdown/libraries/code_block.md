---
title: 代码块
---
### 行内代码块
构建器支持行内代码块。

你可以在一行的任意位置添加 `codeblock` 代码块，就像这样。

### 块状代码块
从 Pagebuilder 0.14.2 起，构建器支持块状代码块。

但由于 WPF 的诸多限制，现版本的构建器暂不支持语法高亮和行数显示。

```python
WELCOME = "Hello World"
print(WELCOME)
```